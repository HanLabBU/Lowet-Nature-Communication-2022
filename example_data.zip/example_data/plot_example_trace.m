
%% load data
ses=dir('*.mat');
Cpath= ses(1).name;
load(Cpath)  %loading

  FS=828; %sampling rate
 trials_id= unique(result.trial_vec);
   figure('COlor','w','Position',[ 300 300 350 300])
   tr=0;
    for  ne= trials_id % trials
        tr=tr+1;
        %% Vm
        v= result.traces(result.trial_vec==ne);  
        v(1:2)=v(3); % first two time point are black occuring before shutter opens
   [ fitbaseline, coeff]=exp_fit_Fx(v,FS);
   v=(v-fitbaseline');
   tim_axis=([1:size(v,1)]-(FS))./FS;
        plot( tim_axis,zscore(v)./6 +tr,'k');
        hold on,
    end
     line([0 1],[ 11 11],'COlor',[ 0.9 0.5 0.3],'Linewidth',2)
      axis tight
     ylabel('trials')
     xlabel('Time sec')
     title('40Hz DBS, 30mA')